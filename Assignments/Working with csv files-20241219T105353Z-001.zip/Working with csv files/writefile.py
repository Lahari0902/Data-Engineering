
# reate new csv file and add some records in it.

import csv
filepath='Myfiles.csv'
with open(filepath,'w',newline="") as file:
   csvwriter=csv.writer(file)
   csvwriter.writerow(["Id","Name","Age","Courses_Enrolled"])
   data=[[1,"Aparna",20,3],
[2,"Stella",20,1],
[3,"kishore",21,4]]
   csvwriter.writerows(data)
print("writing had been completed")

#adding new records

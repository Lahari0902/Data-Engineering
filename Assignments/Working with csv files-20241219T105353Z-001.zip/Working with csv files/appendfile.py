
#appned data records in the existing csv file

import csv
filepath="Myfiles.csv"
with open(filepath, 'a', newline="") as file:
    csvwriter = csv.writer(file)
    new_data = [
    [4, "John", 22, 2],
    [5, "Maria", 19, 3],
    [6, "Anil", 23, 4]
]
    csvwriter.writerows(new_data)
    

 

print("Additional records have been added.")
